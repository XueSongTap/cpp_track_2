package.cpath = "luaclib/?.so"

local so2 = require "reg2.c"
local so1 = require "reg1.c"


so1.echo("hello world")
so2.echo("hello world")

so1.echo("hello world")
so2.echo("hello world")

so1.echo("hello world")
so2.echo("hello world")

so1.echo("hello world")
so2.echo("hello world")

so1.echo("hello world")
so2.echo("hello world")

so1.echo("hello world")
so2.echo("hello world")