return {
    ["mark"] = "0voice.mark1231231",
    ["darren"] = "0voice.darren00000",
    ["king"] = "0voice.king",
}